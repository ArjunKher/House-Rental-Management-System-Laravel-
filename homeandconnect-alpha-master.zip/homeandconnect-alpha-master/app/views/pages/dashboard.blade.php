@extends('layouts.dashboard')
  @section('title')
    Home
  @stop

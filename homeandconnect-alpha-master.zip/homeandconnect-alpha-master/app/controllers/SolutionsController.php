<?php

class SolutionsController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$solution = Solutions::create([
				'complaintid' => Input::get('complaintid'),
				'response' => Input::get('solution'),
				'date' => Carbon\Carbon::now()->toDateString()
			]);

		$complaint = Complaints::find(Input::get('complaintid'));
		$complaint->solution()->attach($solution,['status'=>'solved']);
		
		Session::flash('success-message','Complaint Solved');
		return Redirect::to('complaints');
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$complaint = Complaints::find($id);
		return View::make('complaints.action')
			->with('complaint',$complaint);
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}


}
